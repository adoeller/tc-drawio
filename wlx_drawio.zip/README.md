# DrawioWLX – nativer draw.io-Viewer (in Entwicklung)

Eigenständiges Total-Commander-Lister-Plugin für Win32 und Win64. Der Viewer
verwendet native Win32-Fenster und Pascal-Grafikbibliotheken, weder LCL noch
WebView. Die Darstellung ist **noch unvollständig**; insbesondere komplexe
Styles, Texte, Stencils und Verbindungen können vom Original abweichen.

Die Projekt-Builds heißen `DrawioWlx.wlx` und `DrawioWlx.wlx64`. Für die
Shape-Bibliotheken liegt die Datei `stencils.min.js` neben der jeweils
verwendeten Plugin-Datei. Sie ist das originale, komprimierte Stencilpaket aus
draw.io v32.6.10 und etwa 3,7 MiB groß. Der Viewer liest sie ausschließlich als
Daten und dekodiert die benötigten Bibliotheken in Pascal; eine JavaScript-Engine
ist nicht erforderlich. Alternativ unterstützt er weiterhin den bisherigen
Ordner `stencils` mit `index.tsv` und Unterordnern, falls die Paketdatei fehlt.
Beides gleichzeitig ist nicht nötig. Bei einer Weitergabe sind die unten
genannten Lizenzen beizulegen. Über die Installation in Total Commander
entscheidet der Nutzer selbst.
Der optionale Ordner `image-assets` enthält einen lokalen URL-zu-Bild-Index
und heruntergeladene Bilder für mehrere Beispiele, darunter Arista-Racks,
Citrix, Cell Culture, Business Model und PESTEL. Auch er muss
neben der verwendeten Plugin-Datei liegen, wenn diese Bilder angezeigt werden
sollen.

Die Total-Commander-Miniaturansicht zeigt bei mehrseitigen Zeichnungen die
erste Seite. Sie verwendet das Stencilpaket beziehungsweise den bisherigen
`stencils`-Ordner, vorhandene `image-assets` und den
aktivierten Bildcache. Fehlende externe Bilder werden entsprechend den
INI-Schaltern nachgeladen. Für Downloads gilt ein gemeinsames Zeitbudget von
drei Sekunden pro Miniatur, wobei ein laufender Netzwerkaufruf darüber hinaus
bis zu seinem Timeout warten kann. Leere, ungültige oder fremde XML-Dateien
liefern kein Miniaturbild.

Die WLX-Erkennung meldet `.drawio` sowie `.xml`, wenn in den ersten 8192 Bytes
`<mxfile` oder `<mxGraphModel` gefunden wird. Das ist ein Vorfilter: sehr lange
XML-Vorläufe und UTF-16-XML werden damit nicht zuverlässig automatisch erkannt;
das Plugin prüft den Inhalt anschließend selbst. Die Datei `pluginst.inf`
beschreibt die WLX für die Installation durch Total Commander. Installation
und Einstellungen nimmt der Nutzer selbst vor: Unter **Konfigurieren →
Einstellungen → Plugins → Lister-Plugins** die WLX eintragen und unter
**Miniaturansicht** bei „Aus Lister-Plugins laden für“ bei Bedarf `*.drawio`
und `*.xml` zum bestehenden Filter ergänzen. Ein vorhandenes `*.*` deckt beide
bereits ab. Bei konkurrierenden XML-Plugins kann die Plugin-Reihenfolge
entscheidend sein. Nach einem Austausch gegebenenfalls die Vorschau aktualisieren
oder den entsprechenden TC-Miniaturcache erneuern.

Der Viewer liest mehrseitige draw.io-Dokumente, darunter komprimierte Seiten,
und zeigt grundlegende Shapes, Verbindungen, eingebettete Bilder und einen
Teil der Stencils. Dazu gehören erste BPMN- und AWS-Formen, Logikgatter,
Tabellen mit verbundenen Zellen, Pfeil-Shapes und Farbverläufe auf Grundformen
und Stencil-Füllungen. Die Floorplan-Formen für Wände, Räume, Fenster,
einfache Türen und Treppen werden nativ gezeichnet; weitere Einrichtungsformen
stammen aus der Stencil-Bibliothek.
Umgebrochene HTML-Beschriftungen werden bei knapp passenden Zeilen innerhalb
ihrer Textbreite eingepasst; ausdrücklich sichtbarer Überlauf für nicht
umbrechbare Texte bleibt erhalten.
Transparenter schwarzer und weißer Text wird mit einem GDI-Zeichendurchlauf
erzeugt. Ein begrenzter, threadgebundener Zeichenpuffer wird innerhalb eines
Renderdurchlaufs wiederverwendet; farbiger Text behält die bisherige
Deckkraftberechnung.
UML-Sequenzdiagramme unterstützen Rahmen, Lebenslinien mit rechteckigem Kopf,
Akteur oder Entität sowie Zerstörungsmarker und Notizen.
UML-Pakete werden mit konfigurierbaren Ordnerreitern und Beschriftungen sowie
Endzustände als doppelte Kreise dargestellt. Farbreferenzen zwischen Füllung
und Kontur berücksichtigen die jeweiligen draw.io-Standardfarben.
UML-Komponentensymbole und der Halbkreis-Marker für Schnittstellen werden
ebenfalls nativ gezeichnet.
Für Timeline-Infografiken stehen kreisförmige und balkenförmige Callouts,
U-Pfeile und Stufenformen einschließlich ihrer Ausrichtung und Spiegelung zur
Verfügung. UML-Aktivitätsdiagramme unterstützen die elektronische
Informationsfluss-Verbindung.
Für die SysML-Beispiele sind unter anderem Paketrahmen, Ports, Objektflüsse,
Aktivitäts- und Endmarker umgesetzt. Balken-, Säulen-, Linien- und
Kreisdiagramme aus der Mockup-Bibliothek werden nativ gezeichnet.
HTML-Beschriftungen berücksichtigen auch bei Zwischenzoomstufen die genauen
Schrift- und Zeilenmaße; Abstände punktförmiger Portbeschriftungen und
Verbindungen zu Mittelpunkt-Knoten werden entsprechend ihrer Position berechnet.
SysML-Paketverbindungen unterstützen den kreuzförmigen Containment-Marker.
Für mobile Mock-ups sind iOS-Telefonrahmen sowie GMDL-Randrechtecke und
Player-Symbole einschließlich ihrer jeweiligen Stilparameter umgesetzt.
Teilkreisbögen, einseitig gefaltete Infografikbanner und iOS-Stecknadeln
werden ebenfalls nativ dargestellt; Bildformen unterstützen horizontale und
vertikale Spiegelung. Bei Würfelformen werden Ausrichtung, Spiegelung und
eine auf die Vorderseite begrenzte Beschriftung berücksichtigt; skizzierte
Stecknadeln erhalten eine gefüllte, farbige Spitze. HTML-Schriftgrößen aus `font size` orientieren sich an
den Browser-Standardgrößen. Der Rough.js-Skizzenstil unterstützt Rechtecke
mit einfarbiger oder schraffierter Füllung, abgerundete schraffierte Rechtecke,
iOS-Stecknadeln und ausgewählte horizontale Swimlanes, Tabellen und Notizen.
Andere Skizzenformen werden weiterhin als vereinfacht gemeldet.
Die Mockup-Formen für Icon-Gitter, Such- und Kombinationsfelder, Videoplayer
und Linien sowie der iOS-Fortschrittsbalken werden nativ dargestellt. UML-
Zeitdiagramme unterstützen Maßlinien und den benannten Stil für Skalenstriche.
Text mit sichtbarem Überlauf darf über die Zellgrenzen hinausreichen; explizit
beschnittene Textfelder bleiben begrenzt.
Orthogonale Verbindungen und Segmentverläufe verwenden die in Pascal
übertragenen draw.io-Router; Anschlussrichtungen, feste und freie Endpunkte,
Stützpunkte, Selbstverbindungen und abgerundete Knicke werden berücksichtigt.
Für noch nicht unterstützte Anschlusskonturen oder Spezialfälle bleibt ein
Darstellungshinweis bestehen.
Elbow-Verbindungen berücksichtigen feste Anschlusspunkte; gestrichelte
Verbindungen ohne Linienübersprünge und unterstützte Konturen beachten
Strichmuster und Strichbreite.
Abgerundete gestrichelte Rechtecke, Ellipsen und gestrichelte SysML-Ereignisformen werden
gezeichnet. Nicht unterstützte gestrichelte Formen melden weiterhin einen
Hinweis.
Die Verbindungsmarker `diamondThin` und `circle` berücksichtigen ihre Größe,
Füllung und den passend verkürzten Linienverlauf. Notizformen unterstützen die
Abdunklung beziehungsweise Aufhellung ihrer gefalteten Ecke.
Linienübersprünge an Kreuzungen mit zuvor gezeichneten Verbindungen werden für
`gap`, `arc`, `sharp` und `line` dargestellt. Kurven, doppelte Link-Verbindungen
und die Beschränkung auf dieselbe Ebene (`jumpLayers=0`) bleiben dabei offen.
Vertikale Beschriftungen und ihre Kombination mit Formdrehungen werden für
einfachen sowie HTML-formatierten Text in 90-Grad-Schritten dargestellt.
Unrotierte Rechtecke, Ellipsen, Tabellen, Rauten und Notizen unterstützen
Schatten mit Versatz, Farbe, Deckkraft und näherungsweiser Unschärfe. Bei
abgerundeten Rauten folgt der Schatten der Rundung; nach Westen gerichtete
Notizen und ihre Schatten werden gedreht. Skizzierte Rechtecke mit Schraffur
werden angenähert dargestellt; der Vereinfachungshinweis bleibt dabei bestehen.
Die obere Leiste bietet Zoom, **Passend** und **Raster**. Bei mehrseitigen
Dateien erscheinen darunter Seiten-Tabs; über die Pfeile rechts oder das
Mausrad auf der Tab-Leiste lassen sich weitere Tabs erreichen. **Bild auf/ab**
wechselt die Seite, **+/-** zoomt, **C** passt die Ansicht ein und **G** schaltet
das Raster um. Mit der Maus lässt sich die Ansicht verschieben.
Während des Ziehens wird die bereits gezeichnete Ansicht unmittelbar verschoben;
nach dem Loslassen wird der Ausschnitt vollständig neu aufgebaut. Neu sichtbar
werdende Randbereiche erscheinen während des Ziehens zunächst in der
Hintergrundfarbe. Die Pfeiltasten **Auf/Ab** werden an das übergeordnete
Lister-Fenster weitergereicht, insbesondere für die Dateiauswahl in Quickview.
Im aktiven Lister bleibt die Tastaturnavigation auch nach einem Dateiwechel
erhalten; im Quickview bleibt der Fokus beim Total Commander.

Ein Rechtsklick öffnet das Kontextmenü zum Speichern der gesamten Seite als
PNG, zum Kopieren als Bild oder Text und zum Umschalten des Rasters. Ein Klick
auf Text markiert ihn; **Strg+Klick** erweitert oder verkleinert die Auswahl.
Textkopie berücksichtigt diese Auswahl und kopiert ohne Auswahl den gesamten
Seitentext. Die Lister-Befehle für Kopieren, Alles auswählen, Zoom, Textsuche
und Drucken werden unterstützt. Die Suche prüft wie im Visio-Plugin die
aktuelle Seite; sie hebt Treffer nicht hervor und setzt nicht an einer
vorherigen Trefferposition fort. Ganzwort- und Rückwärtssuche werden dabei
nicht gesondert ausgewertet. Drucken zeigt den Windows-Dialog und gibt
die gesamte aktuelle Seite aus.

Die Statusleiste meldet erkannte
Einschränkungen; ein Klick darauf zeigt Einzelheiten. Fehlende Hinweise sind
noch kein Nachweis vollständiger Darstellung. Die Oberfläche unterstützt
TC-Dark-Mode und DPI-Skalierung; das Diagramm behält seine eigenen Farben.
Kleine Diagrammtexte werden wie im Visio-Plugin zunächst höher aufgelöst
gerastert und flächengemittelt verkleinert; ein begrenzter Cache beschleunigt
wiederholtes Zeichnen. Bei sehr großen Textflächen wird direkt gerastert.

Ein automatischer Download und Cache externer Bilder ist begonnen, aber noch
nicht abschließend geprüft; der genaue Zwischenstand steht in der Statusdatei.
Eingebettete SVGs werden begrenzt und gerastert; lokale SVG-Verlaufsreferenzen,
einfache CSS-Regeln, lokale Pfadmarker und SVG-Text werden unterstützt. Der
Text wird über Windows-GDI ohne LCL oder zusätzliche Schrift-DLL gerastert.
Nicht unterstützte CSS- oder Markerfälle werden gemeldet. HTML-Beschriftungen unterstützen unter anderem Überschriften,
Absätze, Umbrüche, horizontale Trennlinien, Links, `align`-Attribute,
CSS-Zeilenhöhen sowie verschachtelte Fett-, Kursiv- und Unterstreichungsstile,
Schriftfarben, die CSS-Leerraumarten `normal`, `nowrap` und `pre` sowie einen
Teil der CSS-Schriftangaben. Tabulatoren in `pre` und weitere Leerraumarten
bleiben eingeschränkt und werden gemeldet. Komplexes HTML/CSS und
Verläufe auf weiteren Formen bleiben teilweise vereinfacht. HTML- und einfache
Textbeschriftungen unterstützen Drehungen um 90, 180 und 270 Grad. Weitere
Einschränkungen und Teststand stehen in [STATUS.md](STATUS.md).
Ein nativer, begrenzter Formelsatz unterstützt ausgewählte LaTeX- und
AsciiMath-Ausdrücke einschließlich Brüchen, Wurzeln, Indizes, Matrizen,
skalierbaren Klammern, Grenzen über beziehungsweise unter Operatoren sowie
ausgewählten aufrechten, fetten und kursiven Mathe-Schriftstilen. Nicht unterstützte Ausdrücke erscheinen weiterhin als
Quelltext und werden gemeldet. Auch für Drehung, Beschriftungshintergrund und
komplexe HTML-Einbettung von Formeln bleibt ein Hinweis erhalten. Der Satz
entspricht noch nicht vollständig MathJax; allein das Aktivieren der
Mathematikoption erzeugt keinen Hinweis mehr.
Beschriftungen unterstützen explizite Hintergrund- und Rahmenfarben, auch mit
Alpha, sowie `textOpacity`. Fehlt ein Hintergrund oder steht er auf `none`,
bleibt er transparent. Die spezielle draw.io-Variante `labelBackgroundColor=default`
mit einer aus der Linie ausgeschnittenen Seitenfarbe ist noch nicht umgesetzt.
Der Stand der einzelnen visuellen Vergleiche steht in [VERGLEICH.md](VERGLEICH.md).

## Quellen und Lizenzen

- Die Stencil-Daten stammen aus draw.io v32.6.10. Die Lizenzdateien liegen in
  `vendor/drawio/STENCIL-LICENSE` und `vendor/drawio/LICENSE` (auch als
  `stencils/LICENSE.drawio` und `stencils/LICENSE.apache-2.0` vorhanden); die dort
  beschriebenen Einschränkungen für Atlassian-Produkte beachten.
- Die übrigen JavaScript-Originalquellen in `vendor/drawio` dienen als Referenz
  und Entwicklungswerkzeug; Lizenz: `vendor/drawio/LICENSE`. Die Paketdatei ist
  eine unveränderte Kopie von `vendor/drawio/stencils-source.js`.
- Die übertragenen Linienalgorithmen aus Rough.js 4.6.6 stehen unter der
  MIT-Lizenz in `vendor/drawio/ROUGH-LICENSE`; `rough.min.js` dient nur dem
  Entwicklungsvergleich und wird zur Plugin-Laufzeit nicht ausgeführt.
- Der Schraffuralgorithmus verwendet außerdem `hachure-fill` 0.5.2; dessen
  MIT-Lizenz steht in `vendor/drawio/HACHURE-FILL-LICENSE`.
- Die Kurvenzerlegung basiert auf `points-on-curve` 0.2.0; die MIT-Lizenz steht
  in `vendor/drawio/POINTS-ON-CURVE-LICENSE`.
- `image-assets` enthält aus der öffentlichen diagrams.net-Bibliothek
  [drawio-libs](https://github.com/jgraph/drawio-libs) erzeugte PNGs; die
  zugehörige Lizenz liegt unter `image-assets/LICENSE.drawio-libs`. Das Skript
  `tools/fetch_rack_assets.py` dokumentiert Download und Umwandlung der
  eingebetteten Rasterbilder für die Rackbeispiele.
- Das Citrix-Beispiel referenziert zusätzlich das Ordnersymbol bei
  [Iconfinder](https://cdn4.iconfinder.com/data/icons/ionicons/512/icon-ios7-folder-outline-128.png).
  Es liegt für die Offline-Anzeige ebenfalls in `image-assets`; seine Quelle ist
  separat von den Bildern aus `drawio-libs` im Index vermerkt.
- `cell-culture-flow.drawio` referenziert ein
  [Thermometerbild von Iconfinder](https://cdn2.iconfinder.com/data/icons/freecns-cumulus/32/519875-84_Thermometer_Full-128.png).
  Es liegt für die Offline-Anzeige ebenfalls in `image-assets`. Das Skript
  `tools/fetch_cell_culture_asset.py` dokumentiert den Download.
- Das Preissymbol in `business-model-canvas-table.drawio` stammt ebenfalls von
  [Iconfinder](https://cdn4.iconfinder.com/data/icons/evil-icons-user-interface/64/price-128.png).
  Es ist in `image-assets` für die Offline-Anzeige indiziert;
  `tools/fetch_business_model_asset.py` dokumentiert den Download.
- Die vier PNG-Bildadressen aus `pestel-analysis.drawio` stammen von Iconfinder
  und sind ebenfalls für die Offline-Anzeige indiziert. Das Skript
  `tools/fetch_pestel_assets.py` enthält die einzelnen Quellen und den Download.
- Das Wal- und das Baumsymbol aus `infographic-water-cycle.drawio` stammen von
  Iconfinder und sind für die Offline-Anzeige in `image-assets` indiziert.
  `tools/fetch_water_cycle_assets.py` dokumentiert Quellen und Download.
- BGRABitmap und GDI-Textbausteine stammen aus dem Visio-Projekt. Die Lizenz
  der Bibliothek steht in `vendor/bgrabitmap/COPYING.modifiedLGPL.txt`.
- Die flächengewichtete Verkleinerung für Texte wurde aus
  `wlx_visio/uvisio_textsampling.pas` übernommen und für die
  draw.io-Textausgabe eingebunden.

## Bauen und testen

Mit Lazarus `DrawioWlx.lpi` in den Modi `Release 64` und `Release 32` bauen.
Die beiden Testreihen werden im Projektordner gestartet:

```powershell
powershell -ExecutionPolicy Bypass -File test/run_foundation_tests.ps1
powershell -ExecutionPolicy Bypass -File test/run_native_tests.ps1
powershell -ExecutionPolicy Bypass -File test/run_navigation_tests.ps1
powershell -ExecutionPolicy Bypass -File test/run_thumbnail_tests.ps1
powershell -ExecutionPolicy Bypass -File test/run_stencil_bundle_tests.ps1
powershell -ExecutionPolicy Bypass -File test/run_stencil_thumbnail_tests.ps1
```

Die Tests ersetzen keinen visuellen Vergleich mit diagrams.net und keinen
Integrationstest in Total Commander.
